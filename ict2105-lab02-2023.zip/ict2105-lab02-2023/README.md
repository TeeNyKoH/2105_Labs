# ict2105-lab02-2023
Simple UI, Intents and Interactivity
