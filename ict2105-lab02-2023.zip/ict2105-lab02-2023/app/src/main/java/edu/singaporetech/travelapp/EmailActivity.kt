package edu.singaporetech.travelapp

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


/**
 * Activity that emails your friend with a message
 */
class EmailActivity : AppCompatActivity() {

    val TAG: String = "EmailActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_email)

        // TODO findviewbyid for the UI elements
        val previewButton = findViewById<Button>(R.id.buttonPreview)
        val sendEmailButton = findViewById<Button>(R.id.buttonSendEmail)
        val name = findViewById<EditText>(R.id.editTextName)
        val email = findViewById<EditText>(R.id.editTextEmail)
        val city = findViewById<EditText>(R.id.editTextCity)
        val previewEmail = findViewById<TextView>(R.id.previewMessage)
        // TODO set onClickListeners to all the buttons here
        //  or declare the onclick method within the layout XML?


        previewButton.setOnClickListener {
            val nameS = name.text.toString()
            val cityS = city.text.toString()
            val result: String = createEmailMessage(nameS, cityS)
            Log.d(TAG, "onCreate")
            Log.d(TAG, createEmailMessage(nameS, cityS))
            previewEmail.text = result
        }

        sendEmailButton.setOnClickListener {
            val nameS = name.text.toString()
            val cityS = city.text.toString()
            val emailS = email.text.toString()
            val result: String = createEmailMessage(nameS, cityS)
            previewEmail.text = result
            Log.d(TAG, "before send email")
            sendEmail(emailS, result)
            Log.d(TAG, "after send email")

        }
    }


    /**
     * Call an intent to start the email app
     */
    fun sendEmail(email: String, message: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
            intent.putExtra(Intent.EXTRA_SUBJECT, "Going on vacation!")
            intent.putExtra(Intent.EXTRA_TEXT, message)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "There is no email client installed.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

        /**
         * Creates the string to send in the email message
         * @param name
         * @param city
         * @return the email message
         */
        private fun createEmailMessage(name: String, city: String): String {

            val emailMessage: String =
                getString(R.string.hey) + " " + name + " " + getString(R.string.im_going_to) + " " + city + "!"

            return emailMessage
        }

    }
