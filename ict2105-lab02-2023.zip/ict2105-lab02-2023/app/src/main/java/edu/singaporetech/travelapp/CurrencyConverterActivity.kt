package edu.singaporetech.travelapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity that displays UI to convert currency
 */
class CurrencyConverterActivity : AppCompatActivity() {

    val TAG: String = "CurrencyConverterActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_currency_converter)

        // TODO TODO findviewbyid for the UI elements or data binding

        // Find views by id
        val convertButton = findViewById<Button>(R.id.buttonConvert)
        val inputCurrency = findViewById<EditText>(R.id.editTextCurrency)
        val exchangeRate = findViewById<EditText>(R.id.editTextRate)
        val value = findViewById<EditText>(R.id.editTextSingDollar)
        val outputCurr = findViewById<TextView>(R.id.textViewResult)

        // TODO set onClickListeners to all the buttons here

        convertButton.setOnClickListener {
            var valueF:Float
            var exchangeRateF:Float

            if(value.text.toString().isNotEmpty()){
                valueF = value.text.toString().toFloat()
            } else {
                valueF = 0f
            }
            if(exchangeRate.text.toString().isNotEmpty()){
                exchangeRateF = exchangeRate.text.toString().toFloat()
            } else {
                exchangeRateF = 0f
            }

            val result = calculateRate(valueF,exchangeRateF)
            outputCurr.text = "$$result"
        }
        //  or declare the onClick method within the layout XML?

    }

    /**
     * Formula to calculate the destination currency
     * @param value
     * @param exchangeRate
     * @return
     */
    private fun calculateRate(value: Float, exchangeRate: Float): Float {

        // TODO What's the formula you need?

        return String.format("%.2f", value * exchangeRate).toFloat()
    }

}