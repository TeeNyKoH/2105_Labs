package edu.singaporetech.travelapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat


/**
 * Activity that displays UI to convert temperature
 */
class TempConverterActivity : AppCompatActivity() {

    val TAG: String = "TempConverter"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temp_converter)

        // Find views by id
        val convertButton = findViewById<Button>(R.id.convertButton)
        val inputTemperature = findViewById<EditText>(R.id.editTextTemp)
        val outputTemperature = findViewById<TextView>(R.id.textViewTemp)
        val fahrenheitRadioButton = findViewById<RadioButton>(R.id.radioButtonF)
        val celsiusRadioButton = findViewById<RadioButton>(R.id.radioButtonC)
        val clearButton = findViewById<Button>(R.id.clearButton)

        // Set onClickListener for convert button
        convertButton.setOnClickListener {
            if (inputTemperature.text.toString().isEmpty()) {
                Toast.makeText(this, "Please enter a temperature value", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val temperature = inputTemperature.text.toString().toFloat()
            if (fahrenheitRadioButton.isChecked) {
                // Perform fahrenheit to celsius conversion
                val result = convertFahrenheitToCelsius(temperature)
                outputTemperature.text = "$result °C"
            } else if (celsiusRadioButton.isChecked) {
                // Perform celsius to fahrenheit conversion
                val result = convertCelsiusToFahrenheit(temperature)
                outputTemperature.text = "$result °F"
            } else {
                // Handle no radio button selected
                Toast.makeText(this, "Please select a temperature unit", Toast.LENGTH_SHORT).show()
            }
            clearButton.setOnClickListener {
                inputTemperature.text.clear()
                outputTemperature.text = ""
                fahrenheitRadioButton.isChecked = false
                celsiusRadioButton.isChecked = false
            }
        }

    }

    private fun convertFahrenheitToCelsius(fahrenheit: Float): Float {
        //second way to get 2dp
        val df = DecimalFormat("#.##")
        return df.format( (fahrenheit - 32) * 5/9 ).toFloat()
    }

    private fun convertCelsiusToFahrenheit(celsius: Float): Float {
        //second way to get 2dp
        return String.format("%.2f", (celsius - 32) * 5/9).toFloat()

    }
}
