package edu.singaporetech.travelapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Email
import android.widget.Button

/**
 * Lab 02: Travel App
 * Main Screen
 *
 * 2020-01-27: port to kotlin (jeannie)
 * 2023-01-18: fixes for latest platform level
 */
class MainActivity : AppCompatActivity() {

    val TAG: String = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // TODO findviewbyid for the UI elements or data binding
        val buttonClickTemp = findViewById<Button>(R.id.tempButton)
        buttonClickTemp.setOnClickListener {
            val intent = Intent(this, TempConverterActivity::class.java)
            startActivity(intent)
        }

        val buttonClickCurr = findViewById<Button>(R.id.currencybutton)
        buttonClickCurr.setOnClickListener {
            val intent = Intent(this, CurrencyConverterActivity::class.java)
            startActivity(intent)
        }

        val buttonClickEmail = findViewById<Button>(R.id.emailButton)
        buttonClickEmail.setOnClickListener {
            val intent = Intent(this, EmailActivity::class.java)
            startActivity(intent)
        }

        // TODO set onClickListeners to all the buttons here
        //  or declare the onclick method within the layout XML?
    }
}